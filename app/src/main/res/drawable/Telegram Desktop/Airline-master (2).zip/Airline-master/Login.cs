﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Airline
{
    /// <summary>
    /// Реализует авторизацию в базе, сохранение сессии и проверку, имеется ли
    /// незакрытая сессия
    /// </summary>
    internal class Login
    {
        //Путь к файлу идентификатора незакрытой сессии
        const string FILE_SESSION_PATH = "ses.txt";

        //Текущая сессия в БД
        public static DB.Session ?currentSession;

        //Текущий пользователь в БД
        public static DB.User? currentUser;

        //ID незакрытой сессии из файла
        public static int id_unclosed_session = -1;

        //Проверка, закрыта ли предыдущая сессия
        public static bool checkUnclosedSession()
        {
            if (File.Exists(FILE_SESSION_PATH))
            {
                using (StreamReader sr = new StreamReader(FILE_SESSION_PATH))
                {
                    try
                    {
                        id_unclosed_session = int.Parse(sr.ReadLine());
                    }
                    catch
                    {
                        id_unclosed_session = -1;
                    }
                }

                using (var db = new DB.MyDbContext())
                {
                    if (File.Exists(FILE_SESSION_PATH))
                        File.Delete(FILE_SESSION_PATH);

                    currentSession = db.Session.Where
                        (x => x.ID == id_unclosed_session).SingleOrDefault();
                }

                return true;
            }
            return false;
        }

        //Попытка авторизации по логину и паролю
        public static bool SignIn(string email, string password)
        {
            string pwd = hash(password);

            using (var db = new DB.MyDbContext())
            {
                DB.User user = db.Users.Where(x => x.Email == email).SingleOrDefault();

                if (user == null)
                {
                    MessageBox.Show(Messages.Errors.user_doesnt_exist);
                }
                else
                {
                    if (!user.Password.Equals(pwd))
                    {
                        MessageBox.Show(Messages.Errors.wrong_password);
                    }
                    else
                    {
                        if (user.Active != true)
                        {
                            MessageBox.Show(Messages.Errors.user_inactive);
                        }
                        else
                        {
                            try
                            {
                                using (StreamWriter sw = new StreamWriter(FILE_SESSION_PATH))
                                {
                                    currentUser = user;

                                    currentSession = new DB.Session
                                    {
                                        TimeStart = DateTime.Now,
                                        ID_User = currentUser.ID
                                    };
                                    db.Session.Add(currentSession);

                                    db.SaveChanges();

                                    sw.WriteLine(currentSession.ID);
                                    sw.Close();
                                }

                                return true;
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(Messages.Errors.session_unsaved + "\n\n" + ex.Message);
                            }
                        }
                    }
                }
            }
            return false;
        }

        //Закрытие текущей сессии
        public static void Logout()
        {
            if (currentSession != null)
            {
                using (var db = new DB.MyDbContext())
                {
                    currentSession = db.Session.Where(x => x.ID == currentSession.ID).SingleOrDefault();

                    if (currentSession == null) return;

                    currentSession.TimeEnd = DateTime.Now;

                    db.SaveChanges();
                }

                currentSession = null;

                if (File.Exists(FILE_SESSION_PATH))
                    File.Delete(FILE_SESSION_PATH);          
            }
        }

        //Закрытие сессии после вылета программы и сохранение ошибки
        public static void closeUnclosed(string error, bool? systemCrash)
        {
            using (var db = new DB.MyDbContext())
            {
                DB.Session session = db.Session.Where
                    (x => x.ID == id_unclosed_session).SingleOrDefault();

                if (session != null)
                {
                    session.SystemCrash = systemCrash;
                    session.Error = error;

                    db.SaveChanges();
                }

                File.Delete(FILE_SESSION_PATH);
            }
        }

        //Получение хэша пароля md5
        public static string hash(string password)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(password);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                return Convert.ToHexString(hashBytes);
            }
        }
    }
}
