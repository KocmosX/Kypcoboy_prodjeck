﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Airline.Messages
{
    internal class Errors
    {
        public const string
               connection_failed = "Ошибка: подключение к базе не установлено",
               user_doesnt_exist = "Пользователь с таким именем не существует",
               wrong_password = "Пароль неверный",
               session_unsaved = "Не удалось создать сессию",
               no_logout_detected = "No logout detected for your last login on ",
               user_inactive = "Пользователь неактивен, авторизация невозможна";
    }
}
