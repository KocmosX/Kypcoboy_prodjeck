﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Airline.DB
{
    [Table("Users")]
    internal class User
    {
        [Key]
        public int ID { get; set; }

        public int      RoleID { get; set; }
        public int?     OfficeID { get; set; }

        [ForeignKey("OfficeID")]
        public Office? Office { get; set; }

        public string   Email { get; set; }
        public string   Password { get; set; }
        public string   FirstName { get; set; }
        public string?  LastName { get; set; }
        public DateTime? Birthdate { get; set; }
        public bool?     Active { get; set; }
    }
}
