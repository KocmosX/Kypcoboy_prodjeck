﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Airline.DB
{
    [Table("Session")]
    internal class Session
    {
        [Key]
        public int          ID        { get; set; }

        public int ID_User { get; set; }

        public DateTime     TimeStart { get; set; }
        public DateTime?    TimeEnd       { get; set; }
        public string?      Error     { get; set; }
        public bool?        SystemCrash { get; set; }
    }
}
