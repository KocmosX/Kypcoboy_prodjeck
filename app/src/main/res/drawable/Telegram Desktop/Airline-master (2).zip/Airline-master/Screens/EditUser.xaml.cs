﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Airline.Screens
{
    /// <summary>
    /// Логика взаимодействия для EditUser.xaml
    /// </summary>
    public partial class EditUser : Window
    {
        internal static string? UserEmail { get; set; }

        public EditUser()
        {
            InitializeComponent();
            new TextResizer(this);

            tbEmail.Text = UserEmail;

            using (var db = new DB.MyDbContext())
            {
                var user = db.Users.Where(x => x.Email == UserEmail).First();

                tbFirstName.Text = user.FirstName;
                tbLastName.Text = user.LastName;

                rbUser.IsChecked = user.RoleID != 1;
                rbAdmin.IsChecked = user.RoleID == 1;

                foreach (var office in db.Office)
                {
                    var item = new Items.Office { O = office };
                    cbOffice.Items.Add(item);
                    if (office.ID == user.OfficeID)
                        cbOffice.SelectedItem = item;
                }
            }

            btnCancel.Click += (v, s) => Close();
            btnSave.Click += BtnSave_Click;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new DB.MyDbContext())
                {
                    var user = db.Users.Where(x => x.Email == UserEmail).First();

                    user.FirstName = tbFirstName.Text;
                    user.LastName = tbLastName.Text;

                    if (rbUser.IsChecked == true)
                        user.RoleID = 2;
                    else
                        user.RoleID = 1;

                    user.OfficeID = ((Items.Office)cbOffice.SelectedItem).O.ID;

                    db.SaveChanges();
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Incorrect data: " + ex.Message, "can't save changes",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
