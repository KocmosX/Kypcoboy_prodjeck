﻿using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Airline.Screens
{
    /// <summary>
    /// Логика взаимодействия для Login.xaml
    /// </summary>
    public partial class LoginScreen : Window
    {
        public LoginScreen()
        {
            InitializeComponent();

            new TextResizer(this);

            btnLogin.Click += BtnLogin_Click;
            btnExit.Click += BtnExit_Click;

            this.Closed += this_Closed;

            if (Login.checkUnclosedSession())
                new NoLogoutDetected().ShowDialog();
        }

        private void this_Closed(object? sender, EventArgs e)
        {

        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Login.Logout();
            this.Close();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (!btnLogin.IsEnabled) return;
            btnLogin.IsEnabled = false;

            string login = tbLogin.Text, password = tbPassword.Password;

            Task.Run(() =>
            {
                Dispatcher.Invoke(() =>
                {
                    btnLogin.IsEnabled = false;
                });

                if (Login.SignIn(login, password)) {

                    Dispatcher.Invoke(() =>
                    {
                        btnLogin.IsEnabled = false;
                        Window w = new FirstMenu();
                        w.Show();
                        this.Close();
                    });
                    
                }

                Dispatcher.Invoke(() =>
                {
                    btnLogin.IsEnabled = true;
                });
            });
        }

        
    }
}
