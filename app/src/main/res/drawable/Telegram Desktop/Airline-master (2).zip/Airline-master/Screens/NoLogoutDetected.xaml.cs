﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Airline.Screens
{
    /// <summary>
    /// Логика взаимодействия для NoLogoutDetected.xaml
    /// </summary>
    public partial class NoLogoutDetected : Window
    {
        public NoLogoutDetected()
        {
            InitializeComponent();

            new TextResizer(this);

            btnConfirm.Click += BtnConfirm_Click;

            tbNologout.Text = Messages.Errors.no_logout_detected;
            if (Login.currentSession != null)
            {
                tbNologout.Text += Login.currentSession.TimeStart.ToString();
            }
        }

        private void BtnConfirm_Click(object sender, RoutedEventArgs e)
        {
            Login.closeUnclosed(new TextRange(rtbReason.Document.ContentStart,
         rtbReason.Document.ContentEnd).Text, rbtnSystem.IsChecked);
            this.Close();
        }
    }
}
