from fastapi import APIRouter, Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from services.dialog_service import DialogService
from schemas.dialog import DialogOut
from services.auth_service import AuthService
from models import database

dialog_route = APIRouter()
security = HTTPBearer()
auth_service = AuthService()
dialog_service = DialogService()


def get_db():
    try:
        database.connect()
    finally:
        if not database.is_closed():
            database.close()


@dialog_route.get(
    "/{id}",
    status_code=status.HTTP_200_OK,
    response_model=DialogOut | None,
    dependencies=[Depends(get_db)],
)
async def get_dialog(
    id: str,
    cred: HTTPAuthorizationCredentials = Security(security),
) -> DialogOut | None:
    try:
        dialog_id = int(id)
        if auth_service.decode_token(cred.credentials):
            return dialog_service.get_dialog(dialog_id)
        return None
    except ValueError:
        raise HTTPException(400, "ID param it's not number")


@dialog_route.get(
    "/",
    status_code=status.HTTP_200_OK,
    response_model=list[DialogOut] | None,
    dependencies=[Depends(get_db)],
)
async def get_dialogs(
    cred: HTTPAuthorizationCredentials = Security(security),
) -> list[DialogOut] | None:
    try:
        user_id = int(auth_service.decode_token(cred.credentials)["id"])
        if auth_service.decode_token(cred.credentials):
            return dialog_service.get_dialogs(user_id)
        return None
    except ValueError:
        raise HTTPException(400, "ID param it's not number")
