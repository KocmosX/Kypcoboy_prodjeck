import requests

from service.token_service import TokenService
from config import host


class RequestService:
    def __init__(self):
        self.session = requests.Session()
        self.baseurl = f"http://{host}"
        self.token_service = TokenService()

    def make_request(self, method: str, url: str, data=None):
        response = self.session.request(
            method,
            self.baseurl + url,
            json=data,
            headers={
                "Authorization": f"Bearer {self.token_service.get_access_token()}"
            },
        )

        if response.status_code == 401 or response.status_code == 403:
            new_jwt = self.session.post(
                self.baseurl + "/api/auth/refresh",
                headers={
                    "Authorization": f"Bearer {self.token_service.get_refresh_token()}"
                },
            )

            if new_jwt.status_code != 403 and new_jwt.status_code != 401 and new_jwt.status_code != 404:
                access = new_jwt.json()["access_token"]
                refresh = new_jwt.json()["refresh_token"]

                self.token_service.set_access_token(access)
                self.token_service.set_refresh_token(refresh)

                return self.session.request(
                    method,
                    self.baseurl + url,
                    json=data,
                    headers={"Authorization": f"Bearer {access}"},
                )

            return new_jwt

        return response


if __name__ == "__main__":
    interceptor = RequestService()
    response = interceptor.make_request("GET", "/api/user")
    print(response.json())
