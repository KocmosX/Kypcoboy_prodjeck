import json
import websocket
import threading
from functools import partial
from config import host

websocket.enableTrace(False)


class WebsocketService:
    def __init__(self):
        # websocket.enableTrace(False)
        self.ws_url = f"ws://{host}/api/message/ws/"
        self.ws = None

    def send(self, sender_id, reciver_id, content):
        message_data = {
            "sender_id": sender_id,
            "reciver_id": reciver_id,
            "content": content,
        }

        json_message = json.dumps(message_data)

        self.ws.send(json_message)

    def close(self):
        if self.ws:
            self.ws.close()
            self.ws = None

    # just example
    def on_message(self, ws, message):
        json_message = json.loads(message)

    def open(self, sender_id, on_message):
        self.ws = websocket.WebSocketApp(
            self.ws_url + str(sender_id),
            on_message=on_message,
        )

        ws_thread = threading.Thread(target=self.ws.run_forever)
        ws_thread.daemon = True
        ws_thread.start()
