from peewee import DateTimeField, ForeignKeyField, TextField
from models.database import BaseModel
from models.user import User
from datetime import datetime


class Message(BaseModel):
    sender = ForeignKeyField(User)  # type: User
    created_at = DateTimeField(null=False)  # type: datetime
    content = TextField(null=False)
