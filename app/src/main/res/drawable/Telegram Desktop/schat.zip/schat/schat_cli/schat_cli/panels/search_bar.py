import wx


class SearchBarPanel(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)

        self.search_bar = wx.TextCtrl(self)
        self.label = wx.StaticText(self, label="Поиск")

        self.__do_layout()

    def __do_layout(self):
        sizer = wx.BoxSizer(wx.HORIZONTAL)
        sizer.Add(self.label, 0, wx.ALL, 10)
        sizer.Add(self.search_bar, 1, wx.ALL, 10)

        self.SetSizer(sizer)
