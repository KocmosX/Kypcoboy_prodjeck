from pydantic import BaseModel


class UserBase(BaseModel):
    first_name: str
    last_name: str
    email: str
    nickname: str


class UserSignIn(BaseModel):
    login: str
    password: str


class UserSignUp(UserBase):
    password: str


class UserOut(UserBase):
    id: int
