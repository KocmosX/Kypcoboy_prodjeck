from service.requests_service import RequestService


class UserService:
    requests_service = RequestService()

    def get_users(self):
        return self.requests_service.make_request("GET", "/api/user/")

    def get_self(self):
        return self.requests_service.make_request("GET", "/api/user/self")
