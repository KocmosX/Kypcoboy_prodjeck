from service.requests_service import RequestService


class MessageService:
    request_service = RequestService()

    def get_history(self, chat_id):
        return self.request_service.make_request("GET", f"/api/message/{chat_id}")

    def clear_history(self, chat_id):
        return self.request_service.make_request("DELETE", f"/api/message/{chat_id}")
