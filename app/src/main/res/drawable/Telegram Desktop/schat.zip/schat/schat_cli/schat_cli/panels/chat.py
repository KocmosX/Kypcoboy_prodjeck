from datetime import datetime
import json
import wx
import wx.html2

from panels.message import MessageBox
from service.message_service import MessageService


class ChatPanel(wx.Panel):
    def __init__(self, parent, self_user):
        super().__init__(parent)

        self.browser = wx.html2.WebView.New(self)

        self.base_html = """
<html>
<head>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
</head>
<style>
body {
  background: #ffffff;
  width: 90%;
  display: flex;
  flex-direction: column;
  margin-left: auto;
  margin-right: auto;
}

.message {
  width: fit-content;
  max-width: 50%;
    font-family: "Roboto", sans-serif;
  padding: 1rem;
  margin-bottom: 1rem;
  border-radius: 1rem;
  display: flex;
  flex-direction: column;
  box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
}

.message .content {
  word-wrap: break-word;
}

.message .time {
  font-size: 0.75rem; /* 14px */
  line-height: 1rem; /* 20px */
  margin-top: 0.1rem;
  margin-left: auto;
}

.message:last-child {
  margin-bottom: 0rem;
}

.left {
  margin-right: auto;
  background-color: lightgray;
}

.right {
  background-color: lightblue;
  margin-left: auto;
}
</style>
<body>
</body>
</html>
        """

        self.browser.SetPage(self.base_html, "")

        self.message_service = MessageService()

        self.self_user = self_user

        self.scroll_pos = 0

        # self.Bind(wx.EVT_TIMER, self.on_timeout)
        # self.Bind(wx.EVT_CHILD_FOCUS, self.on_set_focus)
        # self.Bind(wx.EVT_SCROLLWIN, self.on_scroll)

        self.after_paint_timer = wx.Timer(self)

        self.__do_layout()

    def __do_layout(self):
        scroll_sizer = wx.BoxSizer(wx.VERTICAL)
        scroll_sizer.Add(self.browser, 1, wx.ALL | wx.EXPAND)
        self.SetSizer(scroll_sizer)

        # self.SetSizer(scroll_sizer)
        # self.SetScrollRate(0, 10)
        pass

    def add_message(self, message):
        content, dt, sender_id = message["content"], message["created_at"], message["sender_id"]

        if "." in dt:
            input_format = '%Y-%m-%dT%H:%M:%S.%f'
        else:
            input_format = '%Y-%m-%dT%H:%M:%S'
        input_datetime = datetime.strptime(dt, input_format)
        formated_datetime = input_datetime.strftime("%d %B %H:%M")

        isMy = message["sender_id"] == self.self_user["id"]

        owner = "right" if isMy else "left"

        js_code = f"""
const messageDiv = document.createElement('div');
messageDiv.className = 'message {owner}';

const contentSpan = document.createElement('span');
contentSpan.className = 'content';
contentSpan.textContent = '{content}';

const lineBreak = document.createElement('br');

const timeSpan = document.createElement('span');
timeSpan.className = 'time';
timeSpan.textContent = '{formated_datetime}';

messageDiv.appendChild(contentSpan);
messageDiv.appendChild(lineBreak);
messageDiv.appendChild(timeSpan);

document.body.appendChild(messageDiv);
        """
        self.browser.RunScript(js_code)
        self.scroll_down()

    def on_message(self, ws, message):
        message = json.loads(message)

        wx.CallAfter(self.add_message, message)

    def load_history(self, chad_id):
        pass
        history = self.message_service.get_history(chad_id)
        if history.status_code != 200:
            return

        history = history.json()

        for message in history:
            self.add_message(message)

    def clear_history(self):
        self.browser.SetPage(self.base_html, "")

    def scroll_down(self):
        js_code = f"""
        document.body.scrollTop = document.body.scrollHeight;
        """
        self.browser.RunScript(js_code)
        # self.SetScrollPos(wx.VERTICAL, 0)
        # self.GetSizer().Clear(True)

    # def add_message(self, message):
    #     sizer = self.GetSizer()

    #     isMy = message["sender_id"] == self.self_user["id"]

    #     owner = wx.ALIGN_RIGHT if isMy else wx.ALIGN_LEFT

    #     sizer.Add(
    #         MessageBox(
    #             self,
    #             isMy,
    #             message["content"],
    #             message["created_at"],
    #         ),
    #         0,
    #         wx.ALL | owner,
    #         13,
    #     )

    #     sizer.Layout()

    #     self.Layout()

    #     self.after_paint_timer.Start(50, oneShot=True)

    # def on_set_focus(self, event):
    #     self.Scroll(0, self.scroll_pos)

    # def on_scroll(self, event):
    #     self.scroll_pos = self.GetScrollPos(wx.VERTICAL)
    #     event.Skip()

    # def scroll_screen_down(self):
    #     self.Scroll(0, self.GetScrollRange(wx.VERTICAL))

    # def on_timeout(self, event):
    #     self.scroll_screen_down()
    #     event.Skip()
