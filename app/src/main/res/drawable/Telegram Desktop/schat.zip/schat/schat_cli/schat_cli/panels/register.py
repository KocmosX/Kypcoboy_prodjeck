import wx


class RegisterPanel(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)

        self.first_name_label = wx.StaticText(self, label="Имя:")
        self.first_name_text = wx.TextCtrl(self)

        self.second_name_label = wx.StaticText(self, label="Фамилия:")
        self.second_name_text = wx.TextCtrl(self)

        self.nickname_label = wx.StaticText(self, label="Имя пользователя:")
        self.nickname_text = wx.TextCtrl(self)

        self.email_label = wx.StaticText(self, label="Почта:")
        self.email_text = wx.TextCtrl(self)

        self.password_label = wx.StaticText(self, label="Пароль:")
        self.password_text = wx.TextCtrl(self, style=wx.TE_PASSWORD)

        self.password_rep_label = wx.StaticText(self, label="Повторите пароль:")
        self.password_rep_text = wx.TextCtrl(self, style=wx.TE_PASSWORD)

        self.error_message = wx.StaticText(self)

        self.register_button = wx.Button(self, label="Зарегистрироваться")

        self.__do_layout()

    def __do_layout(self):
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.first_name_label, 0, wx.ALL, 5)
        sizer.Add(self.first_name_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.second_name_label, 0, wx.ALL, 5)
        sizer.Add(self.second_name_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.nickname_label, 0, wx.ALL, 5)
        sizer.Add(self.nickname_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.email_label, 0, wx.ALL, 5)
        sizer.Add(self.email_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.password_label, 0, wx.ALL, 5)
        sizer.Add(self.password_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.password_rep_label, 0, wx.ALL, 5)
        sizer.Add(self.password_rep_text, 0, wx.EXPAND | wx.ALL, 5)
        sizer.Add(self.error_message, 0, wx.ALL, 5)
        sizer.Add(self.register_button, 0, wx.ALL | wx.ALIGN_CENTER, 5)

        self.SetSizer(sizer)
        sizer.Fit(self)
