from peewee import ForeignKeyField #Импортируем класс ForeignKeyField из модуля peewee. ForeignKeyField используется для определения внешнего ключа в базе данных.
from models.database import BaseModel #Импортируем базовую модель BaseModel из модуля models.database. BaseModel является базовым классом моделей, в котором устанавливается соединение с базой данных.
from models.user import User #Импортируем модель User из модуля models.user. User представляет модель пользователя в системе.


class Dialog(BaseModel): #Определяем класс Dialog, который наследуется от BaseModel. Таким образом, модель Dialog будет иметь все функциональности и свойства, определенные в базовой модели.
    first_user = ForeignKeyField(User)  # type: User  Указывается тип поля. В данном случае, поле first_user будет иметь тип данных User.
    second_user = ForeignKeyField(User)  # type: User Определяем поле second_user в модели Dialog.
