from peewee import CharField, TextField
from models.database import BaseModel


class User(BaseModel):
    first_name = CharField(max_length=100, null=False, unique=False)
    last_name = CharField(max_length=100, null=False, unique=False)
    email = CharField(max_length=150, null=False, unique=True)
    nickname = CharField(max_length=150, null=False, unique=True)
    password_hash = CharField(max_length=255, null=False, unique=False)
    token = TextField(null=True, unique=False)
