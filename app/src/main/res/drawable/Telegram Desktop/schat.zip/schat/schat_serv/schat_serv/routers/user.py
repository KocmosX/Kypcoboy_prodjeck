from fastapi import APIRouter, Depends, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from schemas.user import UserOut
from services.auth_service import AuthService
from services.user_service import UserService
from models import database

user_route = APIRouter()
security = HTTPBearer()
auth_service = AuthService()
user_service = UserService()


def get_db():
    try:
        database.connect()
    finally:
        if not database.is_closed():
            database.close()


@user_route.get(
    "/",
    status_code=status.HTTP_200_OK,
    response_model=list[UserOut] | None,
    dependencies=[Depends(get_db)],
)
async def users(
    cred: HTTPAuthorizationCredentials = Security(security),
) -> list[UserOut] | None:
    if auth_service.decode_token(cred.credentials):
        return user_service.get_users()
    return None


@user_route.get(
    "/self",
    status_code=status.HTTP_200_OK,
    response_model=UserOut | None,
    dependencies=[Depends(get_db)],
)
async def self(
    cred: HTTPAuthorizationCredentials = Security(security),
) -> UserOut | None:
    if auth_service.decode_token(cred.credentials):
        user_id = auth_service.decode_token(cred.credentials)["id"]
        return user_service.get_user_self(user_id)
    return None
