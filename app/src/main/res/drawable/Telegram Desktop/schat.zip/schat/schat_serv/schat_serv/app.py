import os
from dotenv import load_dotenv
from cryptography.fernet import Fernet

import uvicorn
from fastapi import FastAPI

import models
from routers import auth, user, dialog, message


load_dotenv()

# env file vars
title = "schat"
port = int(os.getenv("PORT") or 3000)
host = os.getenv("HOST") or "localhost"

if not os.getenv("CIPHER_KEY"):
    key = Fernet.generate_key()
    with open(".env", "a") as env_file:
        env_file.write(f"CIPHER_KEY={key.decode()}")


app = FastAPI(
    title=title, docs_url="/api/docs", openapi_url="/api/openapi.json", version="1.0"
)

# include all routers
app.include_router(auth.auth_route, prefix="/api/auth", tags=["Auth"])
app.include_router(user.user_route, prefix="/api/user", tags=["User"])
app.include_router(dialog.dialog_route, prefix="/api/dialog", tags=["Dialog"])
app.include_router(message.message_router, prefix="/api/message", tags=["Message"])


@app.get("/")
async def root():
    return f"API server or {title}"


if __name__ == "__main__":
    models.database_create()

    uvicorn.run("app:app", port=port, host=host, reload=True)
