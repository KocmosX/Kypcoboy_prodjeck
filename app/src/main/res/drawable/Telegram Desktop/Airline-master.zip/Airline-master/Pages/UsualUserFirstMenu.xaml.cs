﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Airline.Pages
{
    /// <summary>
    /// Логика взаимодействия для UsualUserFirstMenu.xaml
    /// </summary>
    public partial class UsualUserFirstMenu : Page
    {
        public UsualUserFirstMenu()
        {
            InitializeComponent();

            tbHello.Text = tbHello.Text.Replace(
                "[NAME]", Login.currentUser.FirstName);

            int crashes = -1;
            TimeSpan spent = TimeSpan.Zero;

            using (var db = new DB.MyDbContext())
            {
                var sessions = db.Session.Where(x => x.ID_User == Login.currentUser.ID).ToList();

                foreach (var session in sessions)
                {
                    var item = new Items.Session { 
                        Date = session.TimeStart.Date.ToString().Split(" ")[0],
                        LoginTime = session.TimeStart.TimeOfDay.ToString().Split(".")[0]
                    };
                    if (session.TimeEnd != null)
                    {
                        item.LogoutTime = session.TimeEnd.Value.TimeOfDay.ToString().Split(".")[0];

                        TimeSpan? spentItem = (session.TimeEnd - session.TimeStart);

                        item.TimeSpent = spentItem.ToString().Split(".")[0];
                        spent += spentItem.Value;
                        item.HasErrors = false;
                    }
                    else
                    {
                        item.LogoutTime = "**";
                        item.TimeSpent = "**";
                        item.UnsuccessReason = session.Error;
                        item.HasErrors = true;
                        crashes++;
                    }

                    dgMain.Items.Add(item);
                }
            }

            tbTimeSpent.Text = tbTimeSpent.Text.
                Replace("[TIME_SPENT]", spent.ToString()).
                Replace("[\\t]", "\t").
                Replace("[CRASHES]", crashes.ToString());
        }
    }
}
