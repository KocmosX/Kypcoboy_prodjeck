﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Entity;

namespace Airline.DB
{
    internal class MyDbContext : DbContext
    {
        private const string DataSource = "DESKTOP-DHBAH2P"; //Domain
        private const string InitialCatalog = "Airline"; //Database
        private const string User = "DESKTOP-DHBAH2P\\Admin";
        private const string Password = "";

        public MyDbContext() : base(
            $"Data Source={DataSource};" +
            $"Initial Catalog={InitialCatalog};" +
            $"User id ={User};Password ={Password};" +
            $"Integrated Security=True") {}


        public DbSet<User> Users { get; set; }
        public DbSet<Session> Session { get; set; }
        public DbSet<Office> Office { get; set; }
    }
}
