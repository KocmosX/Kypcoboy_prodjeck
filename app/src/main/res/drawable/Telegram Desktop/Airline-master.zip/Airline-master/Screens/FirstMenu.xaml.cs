﻿using System.Windows;
using System.Windows.Controls;

namespace Airline.Screens
{
    /// <summary>
    /// Логика взаимодействия для FirstMenu.xaml
    /// </summary>
    public partial class FirstMenu : Window
    {
        public FirstMenu()
        {
            InitializeComponent();

            new TextResizer(this);

            if (Login.currentUser.RoleID == 1)
            {
                Page page = new Pages.AdminUserManaging();
                frameContent.Content = page;
            }
            else
            {
                Page page = new Pages.UsualUserFirstMenu();
                frameContent.Content = page;

                btn_add_user.Visibility = Visibility.Hidden;
                btn_add_user.IsEnabled = false;
                btn_add_user.Width = 0;
            }

            btn_exit.Click += (v, e) =>
            {
                Login.Logout();
                Close();
            };

            btn_add_user.Click += (v, e) =>
            {
                new Screens.AddUser().ShowDialog();
                try
                {
                    ((Pages.AdminUserManaging)frameContent.Content).updTable();
                }
                catch { }
            };
        }
    }
}
