﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Airline.Tables
{
    internal class User
    {
        public string? Name { get; set; }
        public string? LastName { get; set; }
        public string? Age { get; set; }
        public string? UserRole{ get; set; }
        public string? EmailAddress { get; set; }
        public string? Office { get; set; }
        public string? IsActive { get; set; }
    }
}
