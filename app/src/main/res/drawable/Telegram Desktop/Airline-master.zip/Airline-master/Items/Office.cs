﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Airline.Items
{
    internal class Office
    {
        internal DB.Office O;

        public override string ToString()
        {
            if (O != null)
                return O.Title + " | " + O.Contact;
            return "No Office";
        }
    }
}
