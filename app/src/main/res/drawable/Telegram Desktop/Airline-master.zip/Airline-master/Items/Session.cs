﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Airline.Items
{
    internal class Session
    {    
        public string Date { get; set; }
        public string LoginTime { get; set; }
        public string LogoutTime { get; set; }
        public string TimeSpent { get; set; }
        public string UnsuccessReason { get; set; }

        public bool HasErrors { get;set; }
    }
}
