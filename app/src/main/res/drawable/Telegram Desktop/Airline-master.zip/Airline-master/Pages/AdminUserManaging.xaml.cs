﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Airline.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdminUserManaging.xaml
    /// </summary>
    public partial class AdminUserManaging : Page
    {
        public AdminUserManaging()
        {
            InitializeComponent();

            using (var db = new DB.MyDbContext())
            {
                foreach (var o in db.Office)
                {
                    cb_office.Items.Add(new Items.Office {O = o});
                }
                cb_office.Items.Add(new Items.Office { O = null });
            }

            cb_office.SelectedItem = cbitem_all_offices;
            btn_enableDisableLogin.Click += Btn_enableDisableLogin_Click;
            btn_change_role.Click += Btn_change_role_Click;
            btn_editUser.Click += Btn_editUser_Click;
            cb_office.SelectionChanged += Cb_office_SelectionChanged;

            updTable();
        }

        private void Cb_office_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cb_office.SelectedItem == cbitem_all_offices)
                updTable();
            else
            {
                var item = ((Items.Office)cb_office.SelectedItem).O;
                if (item != null)
                    updTable(item.ID);
                else
                    updTable(null, false);
            }
        }

        private void Btn_editUser_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItems.Count == 0)
            {
                MessageBox.Show("Choose users to edit first", "index not found",
                    MessageBoxButton.OK, MessageBoxImage.Question);
                return;
            }
            Screens.EditUser.UserEmail = ((Tables.User)dgUsers.SelectedItems[0]).EmailAddress;
            new Screens.EditUser().ShowDialog();
            updTable();
        }

        private void Btn_change_role_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new DB.MyDbContext())
            {
                foreach (var user in db.Users)
                {
                    foreach (Tables.User user2 in dgUsers.SelectedItems)
                    {
                        if (user.Email == user2.EmailAddress && user.Email != Login.currentUser.Email)
                        {
                            if (user.RoleID == 2)
                                user.RoleID = 1;
                            else
                                user.RoleID = 2;
                        }
                    }
                }
                db.SaveChanges();
            }

            updTable();
        }

        private void Btn_enableDisableLogin_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new DB.MyDbContext())
            {
                foreach (var user in db.Users)
                {
                    foreach (Tables.User user2 in dgUsers.SelectedItems)
                    {
                        if (user.Email == user2.EmailAddress && user.Email != Login.currentUser.Email)
                        {
                            user.Active = !user.Active;
                        }
                    }
                }
                db.SaveChanges();
            }

            updTable();
        }

        public void updTable(int? ID_Office = null, bool all_offices = true)
        {
            List<Tables.User> users = new List<Tables.User>();
            using (var db = new DB.MyDbContext())
            {
                List<DB.User> db_users;

                if (ID_Office == null && all_offices)
                {
                    db_users = db.Users.Include("Office").ToList();
                }
                else
                {
                    db_users = db.Users.Include("Office").
                        Where(x => x.OfficeID == ID_Office).ToList();
                }

                foreach (var db_user in db_users)
                {
                    string age;
                    DateTime now = DateTime.Today;
                    if (db_user.Birthdate == null)
                        age = "-";
                    else
                    {
                        int agee = now.Year - db_user.Birthdate.Value.Year;
                        if (db_user.Birthdate > now.AddYears(-agee)) agee--;
                        age = agee.ToString();
                    }

                    string rolename;
                    if (db_user.RoleID == 1)
                        rolename = "Admin";
                    else
                        rolename = "RegularUser";

                    Tables.User user = new Tables.User
                    {
                        Name = db_user.FirstName,
                        LastName = db_user.LastName,
                        Age = age,
                        EmailAddress = db_user.Email,
                        UserRole = rolename,
                        Office = "-"
                    };

                    if (db_user.Office != null)
                        user.Office = db_user.Office.Title;

                    if (db_user.Active == false)
                        user.IsActive = "False";

                    users.Add(user);
                }
            }
            dgUsers.ItemsSource = users;
        }
    }
}
