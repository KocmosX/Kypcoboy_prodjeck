﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Airline.Screens
{
    /// <summary>
    /// Логика взаимодействия для AddUser.xaml
    /// </summary>
    public partial class AddUser : Window
    {
        public AddUser()
        {
            InitializeComponent();
            new TextResizer(this);

            btnCancel.Click += (v, s) => Close();
            btnSave.Click += BtnSave_Click;

            using (var db = new DB.MyDbContext())
            {
                cbOffice.Items.Add(new Items.Office { O = null});

                foreach (var office in db.Office)
                {
                    cbOffice.Items.Add(new Items.Office { O = office });
                }
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new DB.MyDbContext())
                {
                    var user = new DB.User
                    {
                        Email = tbEmail.Text,
                        Active = true,
                        Birthdate = dpBirthDate.DisplayDate,
                        Password = Login.hash(pbPassword.Password),
                        FirstName = tbFirstName.Text,
                        LastName = tbLastName.Text,
                        RoleID = 2
                    };
                    if (cbOffice.SelectedItem != null)
                        user.OfficeID = ((Items.Office)cbOffice.SelectedItem).O.ID;

                    db.Users.Add(user);
                    db.SaveChanges();

                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can't create user: \n\n" + ex.Message, "can't save changes",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
